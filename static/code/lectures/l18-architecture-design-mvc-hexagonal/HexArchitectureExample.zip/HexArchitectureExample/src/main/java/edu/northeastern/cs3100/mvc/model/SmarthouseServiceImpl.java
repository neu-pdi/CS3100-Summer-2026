package edu.northeastern.cs3100.mvc.model;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;


/**
 *
 * This class implements the Smarthouse service, and provides the main
 * logic for creating thermostats, changing their temperatures, and monitoring
 * them. It also provides a method to save all thermostats.
 */

public class SmarthouseServiceImpl implements SmarthouseService{
    private Map<String,Thermostat> thermostats;

    public SmarthouseServiceImpl() {
        thermostats = new HashMap<String,Thermostat>();
    }

    public void createThermostat(String id,int temperature) {
        thermostats.put(id,new ThermostatImpl(id,temperature));
    }

    public void incrementTemperature(String id) {
        if(thermostats.containsKey(id)) {
            thermostats.get(id).incrementTemperature();
        }
    }

    public void decrementTemperature(String id) {
        if(thermostats.containsKey(id)) {
            thermostats.get(id).decrementTemperature();
        }
    }

    public int getTemperature(String id) throws IllegalArgumentException{
        if(thermostats.containsKey(id)) {
            return thermostats.get(id).getTemperature();
        }
        throw new IllegalArgumentException("No thermostat with id "+id);
    }

    public void monitor(String id) {
        if(thermostats.containsKey(id)) {
            thermostats.get(id).enableMonitoring();
        }
    }

    @Override
    public void saveAll(String filename) throws FileNotFoundException {
        PrintStream pw;
        
        pw = new PrintStream(new FileOutputStream(filename));
        for (Thermostat t:thermostats.values()) {
            pw.println(t.getId()+","+t.getTemperature());
        }
        pw.close();
    }
    
}
