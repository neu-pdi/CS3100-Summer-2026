package edu.northeastern.cs3100.monolith;

import java.io.FileNotFoundException;

/**
 * This interface represents a smart house service. This
 * allows clients to create thermostats,
 * change their temperature, monitor them, and save them.
 *
 */
public interface SmarthouseService {
    void createThermostat(String id,int temperature);
    void incrementTemperature(String id);
    void decrementTemperature(String id);
    int getTemperature(String id) throws IllegalArgumentException;
    void monitor(String id);
    void saveAll(String filename) throws FileNotFoundException;
}
