package edu.northeastern.cs3100.hexagonal.service;

import java.util.HashMap;
import java.util.Map;

import edu.northeastern.cs3100.hexagonal.domain.ChangeMonitorPort;
import edu.northeastern.cs3100.hexagonal.domain.PersistPort;
import edu.northeastern.cs3100.hexagonal.domain.Thermostat;
import edu.northeastern.cs3100.hexagonal.domain.ThermostatImpl;

/**
 * This is part of the SERVICE/USE CASE layer.
 * 
 * This class implements the Smarthouse service, and provides the main
 * logic for creating thermostats, changing their temperatures, and monitoring
 * them. It also provides a method to save all thermostats.
 */

public class SmarthouseServiceImpl implements SmarthouseServicePort{
    private Map<String,Thermostat> thermostats;

    public SmarthouseServiceImpl() {
        thermostats = new HashMap<String,Thermostat>();
    }

    public void createThermostat(String id,int temperature) {
        thermostats.put(id,new ThermostatImpl(id,temperature));
    }

    public void incrementTemperature(String id) {
        if(thermostats.containsKey(id)) {
            thermostats.get(id).incrementTemperature();
        }
    }

    public void decrementTemperature(String id) {
        if(thermostats.containsKey(id)) {
            thermostats.get(id).decrementTemperature();
        }
    }

    public int getTemperature(String id) throws IllegalArgumentException{
        if(thermostats.containsKey(id)) {
            return thermostats.get(id).getTemperature();
        }
        throw new IllegalArgumentException("No thermostat with id "+id);
    }

    public void monitor(String id,ChangeMonitorPort monitor) {
        if(thermostats.containsKey(id)) {
            thermostats.get(id).addMonitor(monitor);
        }
    }

    @Override
    public void saveAll(PersistPort persister) {
        for (Thermostat t:thermostats.values()) {
            persister.save(t);
        }
    }
    
}
