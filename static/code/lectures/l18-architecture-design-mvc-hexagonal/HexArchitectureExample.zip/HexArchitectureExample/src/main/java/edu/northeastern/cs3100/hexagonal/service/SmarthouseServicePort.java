package edu.northeastern.cs3100.hexagonal.service;

import edu.northeastern.cs3100.hexagonal.domain.ChangeMonitorPort;
import edu.northeastern.cs3100.hexagonal.domain.PersistPort;
/**
 * This interface represents a port that can be used
 * by the outside world to USE the domain/core.
 *
 * This is part of the SERVICE or USE-CASE.
 *
 * This particular port allows clients to create thermostats,
 * change their temperature, monitor them, and save them.
 *
 */
public interface SmarthouseServicePort {
    void createThermostat(String id,int temperature);
    void incrementTemperature(String id);
    void decrementTemperature(String id);
    int getTemperature(String id) throws IllegalArgumentException;
    void monitor(String id,ChangeMonitorPort monitor);
    void saveAll(PersistPort persister);
}
