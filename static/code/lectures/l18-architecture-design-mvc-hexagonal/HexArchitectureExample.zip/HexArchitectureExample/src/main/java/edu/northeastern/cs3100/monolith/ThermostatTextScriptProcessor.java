package edu.northeastern.cs3100.monolith;

import java.io.FileNotFoundException;


/**
 * This class processes text commands to control the thermostat.
 * It uses the SmarthouseService to perform the operations.
 */

public class ThermostatTextScriptProcessor {
    private SmarthouseService service;

    public ThermostatTextScriptProcessor() {
        service = new SmarthouseServiceImpl();
    }

    public void process(String command) {
        String[] parts = command.split(" ");
        if (parts[0].equals("create")) {
            service.createThermostat(parts[1], Integer.parseInt(parts[2]));
        } else if (parts[0].equals("increment")) {
            service.incrementTemperature(parts[1]);
        } else if (parts[0].equals("decrement")) {
            service.decrementTemperature(parts[1]);
        } else if (parts[0].equals("get")) {
            System.out.println(service.getTemperature(parts[1]));
        } else if (parts[0].equals("monitor")) {
            service.monitor(parts[1]);
        } else if (parts[0].equals("save")) {
            try {
                service.saveAll(parts[1]);
            } catch (FileNotFoundException e) {
                System.out.println("Error saving to file: "+e.getMessage());
            }
        } else {
            System.out.println("Unknown command: "+command);
        }

    }
}
