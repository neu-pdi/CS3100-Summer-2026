This is a simple (but monolithic) implementation of a smart house. 
A smarthouse consists of one or more smart thermostats. A thermostat
is represented by the ThermoStat interface and implemented in the
ThermoStatImpl class.

A smarthouse supports operations to add a thermostat, increment and
decrement a thermostat's temperature. It also supports monitoring
a thermostat. A thermostat, if monitored, will print to the console its current temperature each time it changes.

Finally the ThermostatTextScriptProcessor class represents a "controller" that offers a simple text-based scripting interface.

**To do**

Run the program by running ThermostatRunner.java.

Think about the following aspects of this design:

**Changeability**

  * What if we wish to store the thermostat data in a JSON file? In a database? In a csv file?

  * What if we wish to print the status of a monitored thermostat in a different format (e.g. "ID: XXX changed to XXX degrees")? To a file? What if we wish to do something else when a thermostat's temperature changes (not just print its temperature)?

  * What if there is another way to use the existing thermostats (for example, create groups of thermostats and offer the functionality of changing the temperature of an entire group)

**Testability**

Try to test that verifies that the SmarthouseServiceImpl class works as specified. Now write an automated (e.g. JUnit) test for the same purpose.

**Design**

If you are familiar with the Model, View, Controller (MVC) design, try to identify which parts in the monolith package should be part of the model, view and controller.

  * Is a mapping of this design to MVC even possible?
  
  * If so, how good of an MVC implementation is this?


Now look at an alternative design for the **same* application, in the hexagonal package.