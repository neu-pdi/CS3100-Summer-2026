package edu.northeastern.cs3100.mvc;

import edu.northeastern.cs3100.mvc.controller.SmarthouseController;
import edu.northeastern.cs3100.mvc.controller.ControllerImpl;
import edu.northeastern.cs3100.mvc.model.SmarthouseService;
import edu.northeastern.cs3100.mvc.model.SmarthouseServiceImpl;
import edu.northeastern.cs3100.mvc.view.SmarthouseView;
import edu.northeastern.cs3100.mvc.view.PrintView;

/**
 * This class is the entry point of the application. It provides a simple command-line interface
 * to interact with the SmarthouseService.
 */
public class ThermostatRunner {
    public static void main(String[] args) {
        //create the model
        SmarthouseService model = new SmarthouseServiceImpl();

        //create the view
        SmarthouseView view = new PrintView(System.out);
        
        //create the controller, give it model and view
        SmarthouseController controller = new ControllerImpl(model,System.in,view);
        
        //give control to the controller
        controller.control();
    }
}
