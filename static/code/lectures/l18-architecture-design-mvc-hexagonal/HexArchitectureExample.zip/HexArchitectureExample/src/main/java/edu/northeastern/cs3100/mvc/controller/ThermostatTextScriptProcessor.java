package edu.northeastern.cs3100.mvc.controller;

import java.io.FileNotFoundException;

import edu.northeastern.cs3100.mvc.model.SmarthouseService;
import edu.northeastern.cs3100.mvc.view.SmarthouseView;


/**
 * This class processes text commands to control the thermostat.
 * It uses the SmarthouseService to perform the operations.
 */

public class ThermostatTextScriptProcessor {
    private SmarthouseService service;
    private SmarthouseView view;

    public ThermostatTextScriptProcessor(SmarthouseService serv,SmarthouseView view) {
        service = serv;
        this.view = view;
    }

    public void process(String command) {
        String[] parts = command.split(" ");
        if (parts[0].equals("create")) {
            service.createThermostat(parts[1], Integer.parseInt(parts[2]));
        } else if (parts[0].equals("increment")) {
            service.incrementTemperature(parts[1]);
        } else if (parts[0].equals("decrement")) {
            service.decrementTemperature(parts[1]);
        } else if (parts[0].equals("get")) {
            view.printMessage(""+service.getTemperature(parts[1]));
        } else if (parts[0].equals("monitor")) {
            service.monitor(parts[1]);
        } else if (parts[0].equals("save")) {
            try {
                service.saveAll(parts[1]);
            } catch (FileNotFoundException e) {
                view.printMessage("Error saving to file: "+e.getMessage());
            }
        } else {
            view.printMessage("Unknown command: "+command);
        }

    }
}
