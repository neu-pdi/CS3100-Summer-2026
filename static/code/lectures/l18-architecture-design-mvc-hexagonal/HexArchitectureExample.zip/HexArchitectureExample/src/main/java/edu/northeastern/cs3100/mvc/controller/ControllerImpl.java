package edu.northeastern.cs3100.mvc.controller;

import java.io.InputStream;
import java.util.Scanner;

import edu.northeastern.cs3100.mvc.model.SmarthouseService;
import edu.northeastern.cs3100.mvc.view.SmarthouseView;

public class ControllerImpl implements SmarthouseController {
    private ThermostatTextScriptProcessor processor;
    private Scanner in;
    private SmarthouseView view;
    
    public ControllerImpl(SmarthouseService service, InputStream inStream,SmarthouseView view) {
        processor = new ThermostatTextScriptProcessor(service,view);
        in = new Scanner(inStream);
        this.view = view;
    }
    @Override
    public void control() {
        view.printHelpMenu();
        while (true) {
            String line = in.nextLine();
            if (line.equalsIgnoreCase("exit")) {
                break;
            }
            processor.process(line);
        }
        in.close();
    }
}
