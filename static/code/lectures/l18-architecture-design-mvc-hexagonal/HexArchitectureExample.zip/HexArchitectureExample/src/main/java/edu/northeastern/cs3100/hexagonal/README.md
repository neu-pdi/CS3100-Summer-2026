This package re-designs the application from the monolith package,
but uses the hexagonal architecture (also informally known as the
ports and adapters architecture).

As with the monolith, run ThermostatRunner.java in this package to run this application.

This design is broken down into roughly three layers:

    * Domain: this implements the actual base functionality of the  application. In other words, this contains the "business logic". 

      This layer also defines the port interfaces that it uses (sometimes called the "driven" ports). These
      interfaces are implemented outside this layer.

    * Service: this layer uses the domain layer to provide functionality that the outside world uses. This layer also defines interfaces for this purpose (sometimes called the "driving" ports) The same domain logic
    can be exposed to the outside world through different services (implementing different driving ports). This example shows only one.

    * Infrastructure: this layer implements the ports that are used
    by the domain. This layer defines the actual infrastructure that makes the domain useful in specific applications (e.g. where does the domain persist its data, how exactly do notifications from the domain work, etc.)

**To do**

Look at the README.md file from the monolith package, and see if
this design addresses any of the concerns you may flagged there.

There is room for further improvement. Think about the following:

    * How will you verify whether the ThermostatTextScriptProcessor
      class works as intended? In other words, it parses and processes each script command correctly?

**Design**

If you are familiar with the Model, View, Controller (MVC) design, try to identify which parts in the hexagonal package should be part of the model, view and controller.

  * Is a mapping of this design to MVC even possible?
  
  * If so, how good of an MVC implementation is this?
