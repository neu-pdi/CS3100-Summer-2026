package edu.northeastern.cs3100.hexagonal.domain;

/**
 * This is a port that can be used by the DOMAIN/CORE to
 * notify clients of changes to a thermostat.
 *
 * This is used for monitoring thermostats.
 * 
 * Look at @see PrintMonitorAdapter for an example of
 * how this can be implemented. That implementation is used 
 * in the main method of the application.
 * 
 * Also look at @see LoggingMonitorAdapter for another example of 
 * how this can be implemented. That implementation is used in the tests.
 * 
 * These examples show how different adapters can be created for the same port, 
 * to use the domain in different situations. In other words, the domain is
 * reusable in different contexts, without any changes to the domain code.
 * This is one of the main benefits of the hexagonal architecture.
 */

public interface ChangeMonitorPort {
    void notify(String id,int temperature);
}
