package edu.northeastern.cs3100.mvc.view;

import java.io.OutputStream;
import java.io.PrintStream;

public class PrintView implements SmarthouseView {
    private PrintStream out;

    public PrintView(PrintStream o) {
        out = o;
    }

    @Override
    public void printHelpMenu() {
        out.println("Welcome to the Smarthouse!");
        out.println("Enter commands to control the thermostat, or 'exit' to quit.");
        out.println("Commands:");
        out.println("  create <id> <temperature> - Create a new thermostat with the given id and temperature");
        out.println("  increment <id> - Increment the temperature of the thermostat with the given id");
        out.println("  decrement <id> - Decrement the temperature of the thermostat with the given id");
        out.println("  get <id> - Get the current temperature of the thermostat with the given id");
        out.println("  monitor <id> - Start monitoring changes to the thermostat with the given id");
        out.println("  save <filename> - Save all thermostats to a file with the given filename");
    }

    @Override
    public void printMessage(String message) {
        out.println(message);
    }
}
