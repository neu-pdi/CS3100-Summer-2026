package edu.northeastern.cs3100.mvc.view;

public interface SmarthouseView {
    void printHelpMenu();
    void printMessage(String message);
}
