package edu.northeastern.cs3100.monolith;

import java.util.Objects;

/**
 *
 * This class represents a thermostat whose temperature can be incremented 
 * or decremented by 1.
 */

public class ThermostatImpl implements Thermostat {
    private final String id;
    private int temperature;
    private final int INCREMENT=1;
    private boolean monitoringEnabled;
    
    public ThermostatImpl(String id, int temperature) {
        this.id = id;
        this.temperature = temperature;
        monitoringEnabled = false;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public int getTemperature() {
        return temperature;
    }

    @Override
    public void enableMonitoring() {
        monitoringEnabled = true;
    }

    @Override
    public void incrementTemperature() {
        temperature+=INCREMENT;
        if (monitoringEnabled) {
            System.out.println("Thermostat "+id+": temperature changed to "+temperature);
        }
    }

    @Override
    public void decrementTemperature() {
        temperature-=INCREMENT;
        if (monitoringEnabled) {
            System.out.println("Thermostat "+id+": temperature changed to "+temperature);
        }
    }

    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o instanceof Thermostat other) {
            return other.getTemperature()==temperature && other.getId().equals(this.id);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id,temperature);
    }
}
