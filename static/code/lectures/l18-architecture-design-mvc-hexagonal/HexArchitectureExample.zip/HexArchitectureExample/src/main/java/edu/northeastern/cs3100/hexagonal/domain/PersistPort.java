package edu.northeastern.cs3100.hexagonal.domain;

/**
 * This is a port that can be used by the DOMAIN/CORE but
 * implemented outside the DOMAIN/CORE.
 *
 * This is used for persisting thermostats.
 *
 * Look at @see TextPersistAdapter for an example of
 * how this can be implemented. That implementation is used
 * in the @see ThermostatTextScriptProcessor class.
 *
 * These examples show how different adapters can be created for the same port, 
 * to use the domain in different situations. In other words, the domain is
 * reusable in different contexts, without any changes to the domain code.
 * This is one of the main benefits of the hexagonal architecture.
 */

public interface PersistPort {
    void save(Thermostat thermostat);
}
