package edu.northeastern.cs3100.mvc.controller;


public interface SmarthouseController {
    void control();
}
