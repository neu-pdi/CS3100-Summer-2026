package edu.northeastern.cs3100.hexagonal.infrastructure;

import java.io.IOException;

import edu.northeastern.cs3100.hexagonal.service.SmarthouseServiceImpl;
import edu.northeastern.cs3100.hexagonal.service.SmarthouseServicePort;

/**
 * This class processes text commands to control the thermostat.
 * It uses the SmarthouseService to perform the operations.
 * 
 * This is part of the INFRASTRUCTURE layer, as it is responsible for
 * processing user input and interacting with the service layer.
 */

public class ThermostatTextScriptProcessor {
    private SmarthouseServicePort service;

    public ThermostatTextScriptProcessor() {
        service = new SmarthouseServiceImpl();
    }

    public void process(String command) {
        String[] parts = command.split(" ");
        if (parts[0].equals("create")) {
            service.createThermostat(parts[1], Integer.parseInt(parts[2]));
        } else if (parts[0].equals("increment")) {
            service.incrementTemperature(parts[1]);
        } else if (parts[0].equals("decrement")) {
            service.decrementTemperature(parts[1]);
        } else if (parts[0].equals("get")) {
            System.out.println(service.getTemperature(parts[1]));
        } else if (parts[0].equals("monitor")) {
            service.monitor(parts[1], new PrintMonitorAdapter());
        } else if (parts[0].equals("save")) {
            try {
                service.saveAll(new TextfilePersistAdapter(parts[1]));
            } catch (IOException e) {
                System.out.println("Error saving to file: "+e.getMessage());
            }
        } else {
            System.out.println("Unknown command: "+command);
        }

    }
}
