package edu.northeastern.cs3100.hexagonal.domain;

import java.util.List;
import java.util.Objects;

/**
 * This is part of the DOMAIN/CORE.
 * 
 * This class represents a thermostat whose temperature can be incremented 
 * or decremented by 1.
 */

public class ThermostatImpl implements Thermostat {
    private final String id;
    private int temperature;
    private final int INCREMENT=1;
    private List<ChangeMonitorPort> monitors;

    public ThermostatImpl(String id, int temperature) {
        this.id = id;
        this.temperature = temperature;
        monitors = new java.util.ArrayList<ChangeMonitorPort>();
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public int getTemperature() {
        return temperature;
    }

    @Override
    public void incrementTemperature() {
        temperature+=INCREMENT;
        notifyMonitors();
    }

    @Override
    public void decrementTemperature() {
        temperature-=INCREMENT;
        notifyMonitors();
    }

    private void notifyMonitors() {
        for (ChangeMonitorPort m:monitors) {
            m.notify(id,temperature);
        }
    }

    @Override
    public void addMonitor(ChangeMonitorPort monitor) {
        monitors.add(monitor);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o instanceof Thermostat other) {
            return other.getTemperature()==temperature && other.getId().equals(this.id);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id,temperature);
    }

    
}
