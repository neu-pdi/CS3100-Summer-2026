package edu.northeastern.cs3100.monolith;

/**
 * This class is the entry point of the application. It provides a simple command-line interface
 * to interact with the SmarthouseService.
 */
public class ThermostatRunner {
    public static void main(String[] args) {
        System.out.println("Welcome to the Smarthouse!");
        System.out.println("Enter commands to control the thermostat, or 'exit' to quit.");
        System.out.println("Commands:");
        System.out.println("  create <id> <temperature> - Create a new thermostat with the given id and temperature");
        System.out.println("  increment <id> - Increment the temperature of the thermostat with the given id");
        System.out.println("  decrement <id> - Decrement the temperature of the thermostat with the given id");
        System.out.println("  get <id> - Get the current temperature of the thermostat with the given id");
        System.out.println("  monitor <id> - Start monitoring changes to the thermostat with the given id");
        System.out.println("  save <filename> - Save all thermostats to a file with the given filename");
        
        ThermostatTextScriptProcessor processor = new ThermostatTextScriptProcessor();
        
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        while (true) {
            String line = scanner.nextLine();
            if (line.equalsIgnoreCase("exit")) {
                break;
            }
            processor.process(line);
        }
        scanner.close();
    }
}
