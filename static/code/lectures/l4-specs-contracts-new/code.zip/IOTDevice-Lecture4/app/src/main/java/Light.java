/**
 * This interface represents a single switchable smart light. Such a light
 * has a brightness value.
 */

public interface Light extends Switchable {

    /**
     * Return the brightness of this light in lumens
     * @return an integer value representing the brightness. Must be non-negative
     */
    int getBrightness();
}
