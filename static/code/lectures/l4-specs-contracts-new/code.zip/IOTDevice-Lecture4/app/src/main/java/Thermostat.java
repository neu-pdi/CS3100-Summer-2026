/**
 * This class represents a single thermostat. The thermostat
 * has a name and a current temperature.
 */

public class Thermostat extends BaseIoTDevice {
    private int temperature;

    /**
     * Create a thermostat with the specified name and temperature
     * @param name the name of this thermostat
     * @param temperature the temperature of this thermostat
     */
    public Thermostat(String name,int temperature) {
        super(name);
        this.temperature = temperature;
    }

    @Override 
    public String identify() {
        return String.format("Thermostat display on, currently at %d%% temperature",temperature);
    }

}
