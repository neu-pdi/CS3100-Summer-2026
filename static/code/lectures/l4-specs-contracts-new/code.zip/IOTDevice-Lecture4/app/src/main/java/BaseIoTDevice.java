/**
 * This base class represents common state and behavior shared by IoT devices.
 */
public abstract class BaseIoTDevice implements IoTDevice {
    private final String name;
    private boolean isOn;

    /**
     * Create a device with the specified name.
     *
     * @param name the name of this device
     */
    protected BaseIoTDevice(String name) {
        this.name = name;
        this.isOn = false;
    }

    /**
     * Return the name of this device.
     *
     * @return the device name
     */
    protected String getName() {
        return this.name;
    }

    /**
     * Update whether this device is on.
     *
     * @param value true if this device should be on, false otherwise
     */
    protected void setOnState(boolean value) {
        this.isOn = value;
    }

    /**
     * Return whether this device is on.
     *
     * @return true if this device is on, false otherwise
     */
    public boolean isOn() {
        return this.isOn;
    }
}