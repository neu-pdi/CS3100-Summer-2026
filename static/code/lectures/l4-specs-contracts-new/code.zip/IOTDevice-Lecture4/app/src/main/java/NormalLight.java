/**
 * This class represents a single light. The light has 
 * a power.
 */
public class NormalLight extends BaseSwitchableDevice implements Light {
    protected int brightness;

    /**
     * Construct a light with the given id and power. The
     * light is off by default.
     * 
     * @param id the name of this light
     * @param brightness the brightness of this light
     */
    public NormalLight(String name,int brightness) {
        super(name);
        this.brightness = brightness;
    }

    @Override
    public String identify() {
        return String.format("Light blinks at %d%% brightness",this.brightness);
    }

    @Override
    public int getBrightness() {
        return this.brightness;
    }
    
}
