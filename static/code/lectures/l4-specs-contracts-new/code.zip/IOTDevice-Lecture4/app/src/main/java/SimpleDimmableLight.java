/**
 * This class represents a dimmable light. A dimmable light is a light 
 * whose brightness can be changed. The brightness of this light must be 
 * within a specified range.
 */

public class SimpleDimmableLight extends NormalLight implements DimmableLight {
    public static final int MIN_BRIGHTNESS = 0;
    public static final int MAX_BRIGHTNESS = 100;

    /**
     * Create a new dimmable light with the specified name and brightness
     * @param name the name of this light
     * @param brightness the initial brightness value of this light
     * @throws IllegalArgumentException if the initial brightness value is not within the 
     * range of the MIN_BRIGHTNESS and MAX_BRIGHTNESS defined in this class
     */
    public SimpleDimmableLight(String name,int brightness) throws IllegalArgumentException {
        super(name,1);
        setBrightness(brightness);
    }

    @Override
    /**
     * Set the brightness of this light to the specified value. The value should be within 
     * the range of the MIN_BRIGHTNESS and MAX_BRIGHTNESS defined in this class.
     */
    public void setBrightness(int value) throws IllegalArgumentException {
        if ((value<MIN_BRIGHTNESS) || (value>MAX_BRIGHTNESS)) {
            throw new IllegalArgumentException("Brightness value should be between "+MIN_BRIGHTNESS + " and "+MAX_BRIGHTNESS );
        }
        this.brightness = value;
    }
}
