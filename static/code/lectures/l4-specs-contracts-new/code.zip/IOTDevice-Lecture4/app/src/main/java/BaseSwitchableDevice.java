/**
 * This base class represents common behavior shared by switchable IoT devices.
 */
public abstract class BaseSwitchableDevice extends BaseIoTDevice implements Switchable {
    /**
     * Create a switchable device with the specified name.
     *
     * @param name the name of this device
     */
    protected BaseSwitchableDevice(String name) {
        super(name);
    }

    /**
     * Turn this device on.
     */
    @Override
    public void turnOn() {
        setOnState(true);
    }

    /**
     * Turn this device off.
     */
    @Override
    public void turnOff() {
        setOnState(false);
    }
}