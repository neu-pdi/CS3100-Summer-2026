/**
 * This interface represents an IoT device that can be turned on or off.
 */

public interface Switchable extends IoTDevice {
    /**
     * Turn this device on
     */
    void turnOn();

    /**
     * Turn this device off
     */
    void turnOff();
}
