import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DeviceTest {
    private Switchable livingRoomLight,fan;
    private IoTDevice thermostat;

    @BeforeEach
    public void setup() {
        livingRoomLight = new NormalLight("livingRoomLight", 100);
        fan = new Fan("fan", 50);
        thermostat = new Thermostat("bedroom thermostat",70);
    }

    @Test
    public void testIdentifyDevice() {
        assertEquals("Light blinks at 100% brightness", livingRoomLight.identify());
        assertEquals("Fan spins at 50% speed", fan.identify());
        assertEquals("Thermostat display on, currently at 70% temperature",thermostat.identify());
    }

    @Test
    public void testTurnOn() {
        livingRoomLight.turnOn();
        assertTrue(livingRoomLight.isOn());
    }

    @Test
    public void testTurnOff() {
        fan.turnOff();
        assertFalse(fan.isOn());
    }

}
