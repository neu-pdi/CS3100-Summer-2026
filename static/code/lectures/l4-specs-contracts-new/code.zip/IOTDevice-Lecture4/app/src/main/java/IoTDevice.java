/**
 * This interface represents the operations for a single IoT device.
 * An IoTDevice can identify itself and report whether it is on.
 */
public interface IoTDevice {
    /**
     * Identify this device. How a device identifies itself is up to the individual device
     * @return a string representing the response of the device
     */
    String identify();

    /**
     * Return whether this device is on.
     * @return true if this device is on, false otherwise
     */
    boolean isOn();
}
