
/**
 * This interface represents a light whose brightness can be set to different
 * values. The brightness of a light cannot be negative. Specific implementations
 * may impose additional constraints on the brightness of a light
 */
public interface DimmableLight extends Light {
    /**
     * Set the brightness of this light to the given value
     * @param value the value of brightness that this light should be set to
     * @throws IllegalArgumentException if the brightness value is invalid. Beyond
     * the definition above, specific implementations may define conditions for
     * validity.
     */
    void setBrightness(int value) throws IllegalArgumentException;
}
