/**
 * This interface represents a light whose temperature can be changed. The temperature of 
 * a light gives it a "warm" or "cool" look. 
 */
public interface TunableLight extends Light {

    /**
     * Get the current color temperature of this light
     * @return the current color temperature as a single integer number
     */
    int getColorTemperature();

    /**
     * Set the current color temperature of this list
     * @param temp the color temperature to set this light to
     * @throws IllegalArgumentException if the color temperature is negative. Other conditions 
     * for validity may be imposed by implementations.
     */
    void setColorTemperature(int temp) throws IllegalArgumentException;

}
