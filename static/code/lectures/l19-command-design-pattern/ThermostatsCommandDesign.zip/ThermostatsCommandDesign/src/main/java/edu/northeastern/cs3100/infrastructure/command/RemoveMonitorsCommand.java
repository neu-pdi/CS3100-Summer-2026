package edu.northeastern.cs3100.infrastructure.command;

import java.io.PrintStream;

import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This class represents a command that removes all monitors from a specific
 * thermostat.
 */
public record RemoveMonitorsCommand(String id) implements ThermostatCommand {
    @Override
    public void execute(SmarthouseServicePort service,PrintStream view) {
        service.disableMonitoring(id);
    }

}
