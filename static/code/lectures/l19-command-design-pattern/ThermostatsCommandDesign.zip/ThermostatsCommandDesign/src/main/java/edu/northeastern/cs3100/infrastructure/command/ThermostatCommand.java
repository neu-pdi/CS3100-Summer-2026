package edu.northeastern.cs3100.infrastructure.command;

import java.io.PrintStream;

import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This interface represents a basic command. A command encapsulates all
 * the instructions for an "atomic" operation within this application.
 * 
 * A command may just comprise of instructions for the service or 
 * may ask the view to display things or both.
 */
public interface ThermostatCommand {
    void execute(SmarthouseServicePort service,PrintStream view);
}
