package edu.northeastern.cs3100.infrastructure.command;

import java.io.PrintStream;

import edu.northeastern.cs3100.service.SmarthouseServicePort;


enum ChangeType {Increment,Decrement};

/**
 * This class represents a command to change the temperature (up or down) 
 * of one thermostat, given its id.
 */
public record ChangeTemperatureCommand(String id,TemperatureChangeType type) implements ThermostatCommand {
    @Override
    public void execute(SmarthouseServicePort service,PrintStream view) {
        if (type==TemperatureChangeType.Increment) {
            service.incrementTemperature(id);
        }
        else if (type==TemperatureChangeType.Decrement) {
            service.decrementTemperature(id);
        }
    }


}
