package edu.northeastern.cs3100.service;

import java.util.List;

import edu.northeastern.cs3100.domain.ChangeMonitorPort;
import edu.northeastern.cs3100.domain.PersistPort;
/**
 * This interface represents a port that can be used
 * by the outside world to USE the domain/core.
 *
 * This is part of the SERVICE or USE-CASE.
 *
 * This particular port allows clients to create thermostats,
 * change their temperature, monitor them, and save them.
 *
 */
public interface SmarthouseServicePort {
    void createThermostat(String id,int temperature);
    void incrementTemperature(String id);
    void decrementTemperature(String id);
    int getTemperature(String id) throws IllegalArgumentException;
    void enableMonitoring(String id,ChangeMonitorPort monitor);
    void disableMonitoring(String id);
    List<String> getAllIds();
    void saveAll(PersistPort persister);
}
