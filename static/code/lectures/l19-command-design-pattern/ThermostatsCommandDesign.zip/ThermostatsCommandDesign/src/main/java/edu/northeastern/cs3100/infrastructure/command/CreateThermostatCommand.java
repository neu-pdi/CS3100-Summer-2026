package edu.northeastern.cs3100.infrastructure.command;

import java.io.PrintStream;

import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This class represents a command to create a new thermostat with the specified
 * ID and the specified initial temperature.
 */
public record CreateThermostatCommand(String id,int initialTemperature) implements ThermostatCommand {
    @Override
    public void execute(SmarthouseServicePort service,PrintStream view) {
        service.createThermostat(id,initialTemperature);
    }
}
