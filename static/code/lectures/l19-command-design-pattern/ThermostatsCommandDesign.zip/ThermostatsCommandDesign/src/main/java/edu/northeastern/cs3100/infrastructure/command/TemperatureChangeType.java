package edu.northeastern.cs3100.infrastructure.command;

/**
 * This enum represents the kinds of change to the temperature of a thermostat.
 * It is used by the @link{ChangeTemperatureCommand} class.
 */

public enum TemperatureChangeType {
    Increment,
    Decrement
}
