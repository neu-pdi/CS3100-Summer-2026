package edu.northeastern.cs3100.infrastructure.command;

import java.io.PrintStream;

import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This class represents a command that transmits the menu of commands to the view.
 */
public class ListCommandsCommand implements ThermostatCommand {

    @Override
    public void execute(SmarthouseServicePort service,PrintStream view) {
        view.println("Commands:");
        view.println("  create <id> <temperature> - Create a new thermostat with the given id and temperature");
        view.println("  increment <id> - Increment the temperature of the thermostat with the given id");
        view.println("  decrement <id> - Decrement the temperature of the thermostat with the given id");
        view.println("  get <id> - Get the current temperature of the thermostat with the given id");
        view.println("  addmonitor <id> - Start monitoring changes to the thermostat with the given id");
        view.println("  removemonitors <id> - Remove monitoring of changes for the thermostat with the given id");
        view.println("  changeall <change> - Change the temperatures of all thermostat by the specified number (may be positive or negative)");
        view.println("  save <filename> - Save all thermostats to a file with the given filename");
        view.println("  help - Print this menu of commands");
        view.println("  exit - Exit the program");
    }

}
