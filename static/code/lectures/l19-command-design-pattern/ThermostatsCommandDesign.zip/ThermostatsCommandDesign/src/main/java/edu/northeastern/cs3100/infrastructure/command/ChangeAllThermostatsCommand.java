package edu.northeastern.cs3100.infrastructure.command;

import java.io.PrintStream;
import java.util.List;

import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This class represents a command to change the temperatures of all existing
 * thermostats by the specified increment. The increment may be positive or 
 * negative, making it possible to increase or decrease the temperatures of all 
 * thermostats at once.
 *
 * This is a "macro" command. No such functionality is offered by the service, 
 * but this command uses multiple operations in the service to implement this 
 * "meta operation". This shows the potential of using commands to implement 
 * newer functionality (within limits) without having to change the service at all.
 */
public record ChangeAllThermostatsCommand(int increment) implements ThermostatCommand {

    @Override
    public void execute(SmarthouseServicePort service,PrintStream view) {
        List<String> ids = service.getAllIds();
        TemperatureChangeType typeOfChange;

        if (increment<0) {
            typeOfChange = TemperatureChangeType.Decrement;
        }
        else {
            typeOfChange = TemperatureChangeType.Increment;
        }
        
        for (String id:ids) {
            ThermostatCommand command = new ChangeTemperatureCommand(id,typeOfChange);
            for (int count = 0;count < Math.abs(increment);count +=1) {
                command.execute(service,view);
            }
        }
    }
}
