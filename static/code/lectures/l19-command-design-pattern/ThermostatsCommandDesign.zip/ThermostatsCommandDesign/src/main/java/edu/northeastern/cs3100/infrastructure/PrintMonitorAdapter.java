package edu.northeastern.cs3100.infrastructure;

import edu.northeastern.cs3100.domain.ChangeMonitorPort;

/**
 * This is an adapter that implements the ChangeMonitorPort interface
 * This adapter specifically prints the changes to the console.
 * 
 * This is part of the INFRASTRUCTURE layer.
 */

public class PrintMonitorAdapter implements ChangeMonitorPort {

    @Override
    public void notify(String id, int temperature) {
        System.out.println("Thermostat "+id+": temperature changed to "+temperature);
    }
    
}
