package edu.northeastern.cs3100.infrastructure.command;

import java.io.PrintStream;

import edu.northeastern.cs3100.domain.ChangeMonitorPort;
import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This class represents a command to add a monitor to an existing thermostat
 */

public record AddMonitorCommand(String id,ChangeMonitorPort monitor) implements ThermostatCommand {
    @Override
    public void execute(SmarthouseServicePort service,PrintStream view) {
        service.enableMonitoring(id,monitor);
    }

}
