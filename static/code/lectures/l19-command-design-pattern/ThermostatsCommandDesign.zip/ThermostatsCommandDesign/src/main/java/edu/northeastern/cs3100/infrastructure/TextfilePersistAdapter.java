package edu.northeastern.cs3100.infrastructure;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import edu.northeastern.cs3100.domain.PersistPort;
import edu.northeastern.cs3100.domain.Thermostat;


/**
 * This is an adapter that implements the PersistPort interface
 * This adapter specifically saves the thermostats to a text file.
 * 
 * This is part of the INFRASTRUCTURE layer.
 */

public class TextfilePersistAdapter implements PersistPort {

    private PrintStream file;

    public TextfilePersistAdapter(String filename) throws IOException{
        file = new PrintStream(new FileOutputStream(filename));
    }

    @Override
    public void save(Thermostat thermostat) {
        file.println(thermostat.getId() + "," + thermostat.getTemperature());
    }
    
}
