This package re-designs the application that served as an example for the Hexagonal Architecture. It adds two more commands to it (changeall, removemonitors) and then adds the command design pattern.

Run ThermostatRunner.java in this package to run this application.

This design is broken down into roughly three layers:

**Design**

Changes to the original program:

* Two new options are accepted by the program:
  * `changeall <temperature>`: change the temperature of all thermostat by the given increment
  * `removemonitors <id>`: Remove all monitors from a thermostat with the given id
* The list of options are updated with the above, and the `ThermostatTextScriptProcessor` class has been updated to parse them

**Command Design Pattern**

* A command is an object that uses the service and view in a specific way. In the case of this program, there is one command per option provided by the user when the program is run.
* The `ThermostatCommand` interface in the `command` package represents a single command. 
* Various implementations (one for each option) are provided in the `command` package
* `ThermostatTextScriptProcessor` class is modified to parse the input and merely return the appropriate `ThermostatCommand` object
* A new `ThermostatController` class contains the interaction loop. It uses the processor to get a `ThermostatCommand` object and executes it

**Receiving inputs**

As you know, this program accepts inputs from the user via strings, effectively created a command-line interface (CLI). This program shows three ways to implement the CLI. All ways result in the same behavior.

1. `ThermostatController::control`: this is the "normal" way of using a `Scanner` to accept a line of input and use the processor to parse it. 
2. `ThermostatController::control2`: this uses the `JLine` library to implement the CLI. The `JLine` provides a terminal that can be configured. Once set up, using it is very similar as the first method.
3. `ThermostatController::control3`: this uses the same `JLine` library, but with an tab-complete feature using a `Completer`. This is part of `JLine` but provides a way for the user to use the tab key to auto-complete a partially typed string. The `Completer` completes a partially typed first string in the command.

In the `main` method switch between these methods and run the program to use it.
