package edu.northeastern.cs3100.infrastructure.command;

import java.io.IOException;
import java.io.PrintStream;

import edu.northeastern.cs3100.domain.PersistPort;
import edu.northeastern.cs3100.infrastructure.TextfilePersistAdapter;
import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This class represents a command to save all thermostats and their temperatures
 * to a single text file.
 */
public record TextfilePersistCommand(String filePath) implements ThermostatCommand {
    @Override
    public void execute(SmarthouseServicePort service,PrintStream view) {
        PersistPort port = null;
        
        try {
            port = new TextfilePersistAdapter(filePath);
        } catch (IOException e) {
            System.out.println("Error saving to file: "+e.getMessage());
            return;
        }
        service.saveAll(port);
    }

}
