package edu.northeastern.cs3100.infrastructure.command;

import java.io.PrintStream;

import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This class represents a command to get the temperature of a thermostat with 
 * the specified ID and transmit it to the view.
 */
public record GetTemperatureCommand(String id) implements ThermostatCommand {

    @Override
    public void execute(SmarthouseServicePort service,PrintStream view) {
        int temperature = service.getTemperature(id);
        view.println(temperature);
    }

}
