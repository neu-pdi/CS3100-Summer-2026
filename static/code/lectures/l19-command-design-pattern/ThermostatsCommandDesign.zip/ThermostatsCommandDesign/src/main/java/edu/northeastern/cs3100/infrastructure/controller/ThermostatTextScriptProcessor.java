package edu.northeastern.cs3100.infrastructure.controller;


import edu.northeastern.cs3100.infrastructure.PrintMonitorAdapter;
import edu.northeastern.cs3100.infrastructure.command.AddMonitorCommand;
import edu.northeastern.cs3100.infrastructure.command.ChangeAllThermostatsCommand;
import edu.northeastern.cs3100.infrastructure.command.ChangeTemperatureCommand;
import edu.northeastern.cs3100.infrastructure.command.CreateThermostatCommand;
import edu.northeastern.cs3100.infrastructure.command.GetTemperatureCommand;
import edu.northeastern.cs3100.infrastructure.command.ListCommandsCommand;
import edu.northeastern.cs3100.infrastructure.command.RemoveMonitorsCommand;
import edu.northeastern.cs3100.infrastructure.command.TemperatureChangeType;
import edu.northeastern.cs3100.infrastructure.command.TextfilePersistCommand;
import edu.northeastern.cs3100.infrastructure.command.ThermostatCommand;

/**
 * This class processes text commands to control the thermostat.
 * It uses the SmarthouseService to perform the operations.
 * 
 * This is part of the INFRASTRUCTURE layer, as it is responsible for
 * processing user input and interacting with the service layer.
 */

public class ThermostatTextScriptProcessor {

    public String[] getAllCommandNames() {
        return new String[] {
            "create",
            "increment",
            "decrement",
            "changeall",
            "get",
            "addmonitor",
            "removemonitors",
            "help",
            "save"
        };
    }

    public ThermostatCommand process(String command) {
        String[] parts = command.split(" ");
        ThermostatCommand commandObject = null;
        if (parts[0].equals("create")) {
            //service.createThermostat(parts[1], Integer.parseInt(parts[2]));
            commandObject = new CreateThermostatCommand(parts[1],Integer.parseInt(parts[2]));
        } else if (parts[0].equals("increment")) {
            //service.incrementTemperature(parts[1]);
            commandObject = new ChangeTemperatureCommand(parts[1],TemperatureChangeType.Increment);
        } else if (parts[0].equals("decrement")) {
            //service.decrementTemperature(parts[1]);
            commandObject = new ChangeTemperatureCommand(parts[1],TemperatureChangeType.Decrement);
        } else if (parts[0].equals("changeall")) {
            //service.decrementTemperature(parts[1]);
            commandObject = new ChangeAllThermostatsCommand(Integer.parseInt(parts[1]));
        } else if (parts[0].equals("get")) {
            //System.out.println(service.getTemperature(parts[1]));
            commandObject = new GetTemperatureCommand(parts[1]);
        } else if (parts[0].equals("addmonitor")) {
            //service.enableMonitoring(parts[1], new PrintMonitorAdapter());
            commandObject = new AddMonitorCommand(parts[1],new PrintMonitorAdapter());
        } else if (parts[0].equals("removemonitors")) {
            //service.disableMonitoring(parts[1]);
            commandObject = new RemoveMonitorsCommand(parts[1]);
        } else if (parts[0].equals("help")) {
            commandObject = new ListCommandsCommand();
        } else if (parts[0].equals("save")) {
          //  try {
          //      service.saveAll(new TextfilePersistAdapter(parts[1]));
          //  } catch (IOException e) {
          //      System.out.println("Error saving to file: "+e.getMessage());
          //  }
            commandObject = new TextfilePersistCommand(parts[1]);
        } 
        return commandObject;

    }
}
