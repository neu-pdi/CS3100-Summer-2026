package edu.northeastern.cs3100.infrastructure.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;

import org.jline.reader.LineReader;
import org.jline.reader.LineReaderBuilder;
import org.jline.reader.impl.completer.StringsCompleter;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;

import edu.northeastern.cs3100.infrastructure.command.ListCommandsCommand;
import edu.northeastern.cs3100.infrastructure.command.ThermostatCommand;
import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This class represents the controller of this application.
 * 
 * This controller works by taking input from any InputStream and transmitting
 * output to any view that is represented by a PrintStream.
 * 
 * This controller runs the application in text-mode, accepting text commands 
 * to control the thermostats of a smart home.
 */

public class ThermostatController {
    private SmarthouseServicePort mainService;
    private InputStream in;
    PrintStream view;

    public ThermostatController(SmarthouseServicePort service,InputStream in,PrintStream out) {
        mainService = service;
        this.in = in;
        view = out;
    }

    //jline with completer
    public void control3() {
        ThermostatCommand command;
        
        //welcome message
        view.println("Welcome to the Smarthouse!");
        //print the menu of commands
        new ListCommandsCommand().execute(mainService,view);
        
        ThermostatTextScriptProcessor processor = new ThermostatTextScriptProcessor();
        
        Terminal terminal;
        // Create a terminal
        try {
            terminal = TerminalBuilder.builder()
            .name("custom terminal")
            .streams(in,view)
            .system(true)
            .build();
        } catch (IOException e) {
            view.println("Cannot create terminal...quitting.");
            return;
        }



        //create a completer for all the commands supported by this program
        String [] commandStrings = processor.getAllCommandNames();

        // Create line reader
        LineReader reader =
        LineReaderBuilder.builder()
                .terminal(terminal)
                .completer(new StringsCompleter(commandStrings)) //completer
                .build();



        while (true) {
            String line = reader.readLine(">"); //read the next typed line
            if (line.equalsIgnoreCase("exit")) {
                break;
            }
            //process what was typed and get a command object 
            command = processor.process(line);
            if (command!=null) { //if a command object was returned...
                command.execute(mainService,view); //execute it
            }
        }
    }

    //jline without completer
    public void control2() {
        ThermostatCommand command;
        
        //welcome message
        view.println("Welcome to the Smarthouse!");
        //print the menu of commands
        new ListCommandsCommand().execute(mainService,view);
        
        ThermostatTextScriptProcessor processor = new ThermostatTextScriptProcessor();
        
        // Create a terminal
        Terminal terminal;
        try {
            terminal = TerminalBuilder.builder()
            .name("custom terminal")
            .streams(in,view)
            .system(true)
            .build();
        } catch (IOException e) {
            view.println("Cannot create terminal...quitting.");
            return;
        }

        // Create line reader
        LineReader reader = 
        LineReaderBuilder.builder()
                .terminal(terminal)
                .build();



        while (true) {
            String line = reader.readLine(">"); //read the next typed line
            if (line.equalsIgnoreCase("exit")) {
                break;
            }
            //process what was typed and get a command object 
            command = processor.process(line);
            if (command!=null) { //if a command object was returned...
                command.execute(mainService,view); //execute it
            }
        }
    }

    //simple scanner based input
    public void control() {
        ThermostatCommand command;
        
        //welcome message
        view.println("Welcome to the Smarthouse!");
        //print the menu of commands
        new ListCommandsCommand().execute(mainService,view);
        
        ThermostatTextScriptProcessor processor = new ThermostatTextScriptProcessor();

        Scanner sc = new Scanner(in);
        
        while (sc.hasNext()) {
            String line = sc.nextLine(); //read the next typed line
            if (line.equalsIgnoreCase("exit")) {
                break;
            }
            //process what was typed and get a command object 
            command = processor.process(line);
            if (command!=null) { //if a command object was returned...
                command.execute(mainService,view); //execute it
            }
        }
        sc.close();
    }

}
