package edu.northeastern.cs3100.domain;

/**
 * This is part of the DOMAIN/CORE.
 * 
 * This interface represents a single thermostat in a smart house. Each thermostat
 * has an id and a temperature. Its temperature can be turned up or down. The increments
 * used for temperature changes depends on the implementation.
 * 
 * The thermostat can also be monitored. When the temperature of this thermostat 
 * changes, all monitors that have been added to this thermostat will be notified of the change.
 * The notification will include the id of the thermostat and its new temperature.
 */
public interface Thermostat {
    String getId();
    int getTemperature();
    void incrementTemperature();
    void decrementTemperature();
    void addMonitor(ChangeMonitorPort monitor);
}
