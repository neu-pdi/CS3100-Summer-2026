package edu.northeastern.cs3100.infrastructure.controller;

import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;

import edu.northeastern.cs3100.service.SmarthouseServicePort;

/**
 * This class represents the controller of this application.
 * 
 * This controller works by taking input from any InputStream and transmitting
 * output to any view that is represented by a PrintStream.
 * 
 * This controller runs the application in text-mode, accepting text commands 
 * to control the thermostats of a smart home.
 */

public class ThermostatController {
    private SmarthouseServicePort mainService;
    private Scanner sc;
    PrintStream view;

    public ThermostatController(SmarthouseServicePort service,InputStream in,PrintStream out) {
        mainService = service;
        sc = new Scanner(in);
        view = out;
    }

    //simple scanner based input
    public void control() {
        System.out.println("Welcome to the Smarthouse!");
        System.out.println("Enter commands to control the thermostat, or 'exit' to quit.");
        System.out.println("Commands:");
        System.out.println("  create <id> <temperature> - Create a new thermostat with the given id and temperature");
        System.out.println("  increment <id> - Increment the temperature of the thermostat with the given id");
        System.out.println("  decrement <id> - Decrement the temperature of the thermostat with the given id");
        System.out.println("  get <id> - Get the current temperature of the thermostat with the given id");
        System.out.println("  monitor <id> - Start monitoring changes to the thermostat with the given id");
        System.out.println("  save <filename> - Save all thermostats to a file with the given filename");
        
        ThermostatTextScriptProcessor processor = new ThermostatTextScriptProcessor(mainService);
        
        while (true) {
            String line = sc.nextLine();
            if (line.equalsIgnoreCase("exit")) {
                break;
            }
            processor.process(line);
        }
        sc.close();
    }

}
