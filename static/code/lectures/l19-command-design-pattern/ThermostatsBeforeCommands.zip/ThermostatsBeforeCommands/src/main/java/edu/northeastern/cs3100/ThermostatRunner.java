package edu.northeastern.cs3100;

import edu.northeastern.cs3100.infrastructure.controller.ThermostatController;
import edu.northeastern.cs3100.service.SmarthouseServiceImpl;
import edu.northeastern.cs3100.service.SmarthouseServicePort;

public class ThermostatRunner {
    public static void main(String[] args) {
        SmarthouseServicePort service = new SmarthouseServiceImpl();
        ThermostatController controller = new ThermostatController(service,System.in,System.out);
        controller.control();
    }
}
