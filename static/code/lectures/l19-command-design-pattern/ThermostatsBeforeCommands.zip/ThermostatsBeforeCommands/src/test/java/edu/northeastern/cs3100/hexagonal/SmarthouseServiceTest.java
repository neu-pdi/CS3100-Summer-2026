package edu.northeastern.cs3100.hexagonal;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import edu.northeastern.cs3100.domain.ChangeMonitorPort;
import edu.northeastern.cs3100.service.SmarthouseServiceImpl;
import edu.northeastern.cs3100.service.SmarthouseServicePort;

class LoggingMonitorAdapter implements ChangeMonitorPort {
    List<String> logIds;
    List<Integer> logTemperatures;

    public LoggingMonitorAdapter(List<String> logIds, List<Integer> logTemperatures) {
        this.logIds = logIds;
        this.logTemperatures = logTemperatures;
    }
    @Override
    public void notify(String id, int temperature) {
        logIds.add(id);
        logTemperatures.add(temperature);
    }
}

public class SmarthouseServiceTest {
    @Test
    public void testMonitoring() {
        List<String> logIds = new java.util.ArrayList<>();
        List<Integer> logTemperatures = new java.util.ArrayList<>();
        List<String> expectedLogIds = List.of("t1","t1");
        List<Integer> expectedLogTemperatures = List.of(21,20);
        SmarthouseServicePort service = new SmarthouseServiceImpl();
        service.createThermostat("t1", 20);
        service.monitor("t1", new LoggingMonitorAdapter(logIds, logTemperatures));
        service.incrementTemperature("t1");
        service.decrementTemperature("t1");
        assertEquals(expectedLogIds, logIds);
        assertEquals(expectedLogTemperatures, logTemperatures);
    }
}
