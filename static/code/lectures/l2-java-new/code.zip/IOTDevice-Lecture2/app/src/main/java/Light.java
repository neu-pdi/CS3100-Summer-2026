/**
 * This class represents a single light. The light has 
 * a power.
 */
public class Light extends BaseIoTDevice {
    protected int brightness;


    /**
     * Construct a light with the given id and power. The
     * light is off by default.
     * 
     * @param id the name of this light
     * @param brightness the brightness of this light
     */
    public Light(String name,int brightness) {
        super(name);
        this.brightness = brightness;
        this.isOn = false;
    }

    @Override
    public String identify() {
        return String.format("Light blinks at %d%% brightness",this.brightness);
    }

    public int getBrightness() {
        return this.brightness;
    }
    
}
