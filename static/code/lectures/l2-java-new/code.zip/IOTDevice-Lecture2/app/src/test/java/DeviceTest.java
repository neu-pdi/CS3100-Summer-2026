import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DeviceTest {
    private Light livingRoomLight;
    private DimmableLight bedroomLight;
    private TunableWhiteLight tvLight;
    private IoTDevice fan,thermostat;

    @BeforeEach
    public void setup() {
        livingRoomLight = new Light("livingRoomLight", 100);
        bedroomLight = new DimmableLight("bedroomLight",40);
        tvLight = new TunableWhiteLight("Light behind the TV",50,3000);
        fan = new Fan("fan", 50);
        thermostat = new Thermostat("bedroom thermostat",70);
    }

    @Test
    public void testIdentifyDevice() {
        assertEquals("Light blinks at 100% brightness", livingRoomLight.identify());
        assertEquals("Light dims and brightens to 40% brightness", bedroomLight.identify());
        assertEquals("Light becomes warmer and goes back to 3000 kelvin",tvLight.identify());
        assertEquals("Fan spins at 50% speed", fan.identify());
        assertEquals("Thermostat display on, currently at 70% temperature",thermostat.identify());
    }

    @Test
    public void testTurnOn() {
        livingRoomLight.turnOn();
        assertTrue(livingRoomLight.isOn());
    }

    @Test
    public void testTurnOff() {
        fan.turnOff();
        assertFalse(fan.isOn());
    }

    @Test
    public void testDimming() {
        bedroomLight.setBrightness(20);
        assertEquals(20,bedroomLight.getBrightness());
    }

    @Test
    public void testChangeColorTemperature() {
        tvLight.setColorTemperature(4560);
        assertEquals(4560,tvLight.getColorTemperature());
    }

}
