public class DeviceMain {
    public static void main(String []args) {
        Light light = new Light("livingRoomLight", 100);
        IoTDevice fan = new Fan("fan", 50);
        IoTDevice thermostat = new Thermostat("bedroom thermostat",70);

        System.out.println(light.identify());
        System.out.println("Light on status: "+light.isOn());
        System.out.println(fan.identify());
        System.out.println("Fan on status: "+fan.isOn());
        System.out.println(thermostat.identify());
        
        light.turnOn();
        fan.turnOn();
        
        System.out.println("Light on status: "+light.isOn());
        System.out.println("Fan on status: "+fan.isOn());
        
    }
}
