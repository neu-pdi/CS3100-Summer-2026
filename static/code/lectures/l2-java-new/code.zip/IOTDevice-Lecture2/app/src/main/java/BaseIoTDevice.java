/**
 * This class represents an incomplete implementation of an IoTDevice. It is used to hold
 * things that are common to all IoTDevices to avoid code duplication.
 */
public abstract class BaseIoTDevice implements IoTDevice {
    protected final String name;
    protected boolean isOn;

    protected BaseIoTDevice(String name) {
        this.name = name;
        this.isOn = false;
    }

    @Override
    public void turnOn() {
        this.isOn = true;
    }

    @Override
    public void turnOff() {
        this.isOn = false;
    }

    @Override
    public boolean isOn() {
        return this.isOn;
    }
}
