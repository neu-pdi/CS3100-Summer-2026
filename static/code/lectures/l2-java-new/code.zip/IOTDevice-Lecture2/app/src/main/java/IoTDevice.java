/**
 * This interface represents the operations for a single IoT device.
 * An IoTDevice can identify itself
 */
public interface IoTDevice {
    /**
     * Identify this device. How a device identifies itself is up to the individual device
     * @return a string representing the response of the device
     */
    String identify();

    /**
     * Turn this device on
     */
    void turnOn();

    /**
     * Turn this device off
     */
    void turnOff();

    /**
     * Return whether this device is on
     * @return true if this device is on, false otherwise
     */
    boolean isOn();

    
}
