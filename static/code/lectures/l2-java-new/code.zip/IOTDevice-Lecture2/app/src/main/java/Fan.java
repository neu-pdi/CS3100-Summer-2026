/**
 * This class represents a single fan. The fan has a name and 
 * a single speed.
 */

public class Fan extends BaseIoTDevice {
    private final int speed;

    /**
     * Create a fan with the given id and speed
     * @param name the name of this fan
     * @param speed the speed of this fan.
     */
    public Fan(String name,int speed) {
        super(name);
        this.speed = speed;
    }

    @Override
    public String identify() {
        return String.format("Fan spins at %d%% speed",this.speed);
    }
}
