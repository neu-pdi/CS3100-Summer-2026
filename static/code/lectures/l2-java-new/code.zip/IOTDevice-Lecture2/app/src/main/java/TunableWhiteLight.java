
/**
 * This class represents a white light that can be dimmed and whose color temperature can be changed.
 */
public class TunableWhiteLight extends Light {

    private int colorTemperature;
    public static final int MIN_COLORTEMPERATURE = 2000;
    public static final int MAX_COLORTEMPERATURE = 8000;

    public TunableWhiteLight(String name,int initialBrightness,int initColorTemperature) throws IllegalArgumentException {
        super(name,initialBrightness);
        setColorTemperature(initColorTemperature);
    }

    public int getColorTemperature() {
        return this.colorTemperature;
    }

    public void setColorTemperature(int temp) throws IllegalArgumentException {
        if ((temp<MIN_COLORTEMPERATURE) || (temp>MAX_COLORTEMPERATURE)) {
            throw new IllegalArgumentException("Color temperature must be in the range "+MIN_COLORTEMPERATURE + " to "+MAX_COLORTEMPERATURE);
        }
        this.colorTemperature = temp;
    }

    @Override
    public String identify() {
        return String.format("Light becomes warmer and goes back to %d kelvin",this.colorTemperature);
    }

}
