#create a basic dictionary for an IoT device. It has a type, a unique name and whether it is on or off
def createIoTDevice(type, name):
    """This function creates a dictionary that represents a generic IoT device. It has a key called "type" and another for the unique id of the device """
    device = {'type':type,'name':name,'isOn':False} 
    return device

#check if the given parameter is a valid IoT device
def isIoTDevice(device):
    return (type(device) is dict) and ('type' in device) and ('name' in device) and ('isOn' in device)

#check if the given parameter is a valid light
def isLight(device):
    return (type(device) is dict) and ('type' in device) and (device['type'] == "light") and ('name' in device) and ('power' in device)

#create a dictionary that represents a light
def createLight(name, power):
    """This function takes in the various attributes for a light and returns a dictionary with keys name and power with their respective values equal to whatever was passed to this function. It also has a key called "type" that has the value "light" """
    record = createIoTDevice("light", name)
    record['power'] = power
    return record

#create a dictionary that represents a fan
def createFan(name, speed):
    """This function takes in the various attributes for a fan and returns a dictionary with keys name and speed with their respective values equal to whatever was passed to this function. It also has a key called "type" that has the value "fan" """
    record = createIoTDevice("fan", name)
    record['speed'] = speed
    return record

#create a dictionary that represents a thermostat
def createThermostat(name, temperature):
    """This function takes in the various attributes for a thermostat and returns a dictionary with keys name and temperature with their respective values equal to whatever was passed to this function. It also has a key called "type" that has the value "thermostat" """
    record = createIoTDevice("thermostat", name)
    record['temperature'] = temperature
    return record
    
#check if the given parameter is a fan
def isFan(device):
    return (type(device) is dict) and ('type' in device) and (device['type'] == "fan") and ('name' in device) and ('speed' in device)

#check if the given parameter is a thermostat
def isThermostat(device):
    return (type(device) is dict) and ('type' in device) and (device['type'] == "thermostat") and ('name' in device) and ('temperature' in device)


#function that identifies a device
def identifyDevice(device):
    if isLight(device):
        return "Light blinks at {}% power".format(device['power'])
    elif isFan(device):
        return "Fan spins at {}% speed".format(device['speed'])
    elif isThermostat(device):
        return "Thermostat display on, currently at {} temperature".format(device['temperature'])
    else:
        raise ValueError("Unknown device or not a valid IoT device")

#function that turns on the device
def turnOn(device):
    if isIoTDevice(device):
        device['isOn'] = True
    else:
        raise ValueError("Not a valid IoT device")

#function that turns off the device
def turnOff(device):
    if isIoTDevice(device):
        device['isOn'] = False
    else:
        raise ValueError("Not a valid IoT device")

#function that checks if the device is on
def isOn(device):
    if isIoTDevice(device):
        return device['isOn']
    else:
        raise ValueError("Not a valid IoT device")

#create an instance that represents a living room light
livingRoomLight = createLight("livingRoomLight", 100)

#create an instance that represents a fan
fan = createFan("fan", 50)

#create an instance that represents a thermostat
thermostat = createThermostat("thermostat", 70)

############### tests ###################

#tests for publications defined in a non-OO manner

import unittest

class DeviceTests(unittest.TestCase):
    def setUp(self):
        #create a light and a fan to be used in the tests
        self.livingRoomLight = createLight("livingRoomLight", 100)
        self.fan = createFan("fan", 50)
        self.thermostat = createThermostat("thermostat", 70)
        
    def test_identifyDevice(self):
        self.assertEqual("Light blinks at 100% power", identifyDevice(self.livingRoomLight))
        self.assertEqual("Fan spins at 50% speed", identifyDevice(self.fan))
        self.assertEqual("Thermostat display on, currently at 70 temperature", identifyDevice(self.thermostat))
        
    def test_turnOn(self):
        turnOn(self.livingRoomLight)
        self.assertTrue(isOn(self.livingRoomLight))

    def test_turnOff(self):
        turnOff(self.fan)
        self.assertFalse(isOn(self.fan))

suite = unittest.TestLoader().loadTestsFromTestCase(DeviceTests)
unittest.TextTestRunner(verbosity=2).run(suite)