class IoTDevice: # a structure that represents an IoT device
    """This class represents an IoT device. An IoT device has the following attributes: type, name, and isOn."""
    def __init__(self,type,name): #to instantiate IoT devices
        self.__type__ = type
        self.__name__ = name
        self.__isOn__ = False #by default, an IoT device is off when it is instantiated
    
    #function for an IoT device to identify itself
    def identify(self):
        return "Unknown Device not a valid IoT device"
    #function for an IoT device to turn itself on
    def turnOn(self):
        self.__isOn__ = True
    #function for an IoT device to turn itself off
    def turnOff(self):
        self.__isOn__ = False
    #function for an IoT device to check if it is on
    def isOn(self):
        return self.__isOn__
        
class Light(IoTDevice): # a structure that represents a light
    """This class represents a light-type IoT device. A light has the following attributes: type, id, isOn, and power."""
    def __init__(self,id,power):
        super().__init__("light", id)
        self.__power__ = power

    #function for a light to identify itself
    def identify(self):
        return "Light blinks at {}% power".format(self.__power__)

class Fan(IoTDevice): # a structure that represents a fan
    """This class represents a fan-type IoT device. A fan has the following attributes: type, id, isOn, and speed."""
    def __init__(self,id,speed):
        super().__init__("fan", id)
        self.__speed__ = speed

    #function for a fan to identify itself
    def identify(self):
        return "Fan spins at {}% speed".format(self.__speed__)
            
class Thermostat(IoTDevice): # a structure that represents a thermostat
    """This class represents a thermostat-type IoT device. A thermostat has the following attributes: type, id, isOn, and temperature."""
    def __init__(self,id,temperature):
        super().__init__("thermostat", id)
        self.__temperature__ = temperature

    #function for a thermostat to identify itself
    def identify(self):
        return "Thermostat display on, currently at {} temperature".format(self.__temperature__)         
        
#create an instance that represents a living room light
livingRoomLight = Light("livingRoomLight", 100)

#create an instance that represents a fan
fan = Fan("fan", 50)
#create an instance that represents a thermostat
thermostat = Thermostat("thermostat", 70)

########################## Tests ######################

#tests for publications defined in an OO manner

import unittest

class OODevicesTests(unittest.TestCase):
    def setUp(self):
        #create a light and a fan to be used in the tests
        self.livingRoomLight = Light("livingRoomLight", 100)
        self.fan = Fan("fan", 50)
        self.thermostat = Thermostat("thermostat", 70)
        
    def test_identifyDevice(self):
        self.assertEqual("Light blinks at 100% power", self.livingRoomLight.identify())
        self.assertEqual("Fan spins at 50% speed", self.fan.identify())
        self.assertEqual("Thermostat display on, currently at 70 temperature", self.thermostat.identify())

    def test_turnOn(self):
        self.livingRoomLight.turnOn()
        self.assertTrue(self.livingRoomLight.isOn())

    def test_turnOff(self):
        self.fan.turnOff()
        self.assertFalse(self.fan.isOn())

suite = unittest.TestLoader().loadTestsFromTestCase(OODevicesTests)
unittest.TextTestRunner(verbosity=2).run(suite)