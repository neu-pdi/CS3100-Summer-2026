public class DeviceMain {
    public static void main(String []args) {
        IoTDevice light = new Light("livingRoomLight", 100);
        IoTDevice fan = new Fan("fan", 50);

        System.out.println(light.identify());
        System.out.println("Light on status: "+light.isOn());
        System.out.println(fan.identify());
        System.out.println("Fan on status: "+fan.isOn());
        light.turnOn();
        fan.turnOn();
        System.out.println("Light on status: "+light.isOn());
        System.out.println("Fan on status: "+fan.isOn());
    }
}
