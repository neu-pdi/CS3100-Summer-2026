/**
 * This class represents a single light. The light has 
 * a power.
 */
public class Light implements IoTDevice {
    private final int power;
    private final String name;
    private boolean isOn;

    /**
     * Construct a light with the given id and power. The
     * light is off by default.
     * 
     * @param id the name of this light
     * @param power the power of this light
     */
    public Light(String name,int power) {
        this.name = name;
        this.power = power;
        this.isOn = false;
    }

    @Override
    public String identify() {
        return String.format("Light blinks at %d%% power",this.power);
    }

    @Override
    public void turnOn() {
        this.isOn = true;
    }

    @Override
    public void turnOff() {
        this.isOn = false;
    }

    @Override
    public boolean isOn() {
        return this.isOn;
    }
    
}
