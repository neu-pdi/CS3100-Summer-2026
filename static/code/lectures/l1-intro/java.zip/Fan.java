/**
 * This class represents a single fan. The fan has a name and 
 * a single speed.
 */

public class Fan implements IoTDevice {
    private final String name;
    private final int speed;
    private boolean isOn;

    /**
     * Create a fan with the given id and speed
     * @param name the name of this fan
     * @param speed the speed of this fan.
     */
    public Fan(String name,int speed) {
        this.name = name;
        this.speed = speed;
        this.isOn = false;
    }

    @Override
    public String identify() {
        return String.format("Fan spins at %d%% speed",this.speed);
    }

    @Override
    public void turnOn() {
        this.isOn = true;
    }

    @Override
    public void turnOff() {
        this.isOn = false;
    }

    @Override
    public boolean isOn() {
        return this.isOn;
    }
}
